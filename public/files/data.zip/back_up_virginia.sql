#
# TABLE STRUCTURE FOR: barang
#

DROP TABLE IF EXISTS `barang`;

CREATE TABLE `barang` (
  `idBarang` int(11) NOT NULL AUTO_INCREMENT,
  `tanggalBarang` timestamp NOT NULL DEFAULT current_timestamp(),
  `kodeBarang` varchar(50) NOT NULL,
  `namaBarang` varchar(200) NOT NULL,
  `keterangan` text NOT NULL,
  `gambar` varchar(100) NOT NULL,
  `hargaJual` int(11) NOT NULL,
  `hargaGrosir1` int(11) NOT NULL,
  `hargaGrosir2` int(11) NOT NULL,
  `hargaGrosir3` int(11) NOT NULL,
  `stok` int(11) NOT NULL,
  `hit` int(11) NOT NULL,
  `qrcodeBarang` varchar(100) NOT NULL,
  `barcodeBarang` varchar(100) NOT NULL,
  PRIMARY KEY (`idBarang`)
) ENGINE=InnoDB AUTO_INCREMENT=22 DEFAULT CHARSET=utf8mb4;

INSERT INTO `barang` (`idBarang`, `tanggalBarang`, `kodeBarang`, `namaBarang`, `keterangan`, `gambar`, `hargaJual`, `hargaGrosir1`, `hargaGrosir2`, `hargaGrosir3`, `stok`, `hit`, `qrcodeBarang`, `barcodeBarang`) VALUES (1, '2020-05-10 21:00:52', '958974', 'Kerang Basi', 'Barang Baik dan Kualitas Oke', 'b5a8be268599d317592301773f9905ad.jpg', 2000, 1900, 1800, 1500, 84, 0, '958974-kerang-basi-.png', '958974-kerang-basi-.jpg');
INSERT INTO `barang` (`idBarang`, `tanggalBarang`, `kodeBarang`, `namaBarang`, `keterangan`, `gambar`, `hargaJual`, `hargaGrosir1`, `hargaGrosir2`, `hargaGrosir3`, `stok`, `hit`, `qrcodeBarang`, `barcodeBarang`) VALUES (2, '2020-05-10 21:00:53', '958975', 'Bluset Basi', 'Barang Baik dan Kualitas Oke', '67489c069d48276e51d4b370923bc3cb.jpg', 2000, 1900, 1800, 1500, 80, 0, '958975-bluset-basi-.png', '958975-bluset-basi-.jpg');
INSERT INTO `barang` (`idBarang`, `tanggalBarang`, `kodeBarang`, `namaBarang`, `keterangan`, `gambar`, `hargaJual`, `hargaGrosir1`, `hargaGrosir2`, `hargaGrosir3`, `stok`, `hit`, `qrcodeBarang`, `barcodeBarang`) VALUES (3, '2020-05-10 21:00:53', '958976', 'Nano Basi', 'Barang Baik dan Kualitas Oke', '7868b030a03e68108ae6457df3bc59c2.jpg', 2000, 1900, 1800, 1500, 935, 0, '958976-nano-basi-.png', '958976-nano-basi-.jpg');
INSERT INTO `barang` (`idBarang`, `tanggalBarang`, `kodeBarang`, `namaBarang`, `keterangan`, `gambar`, `hargaJual`, `hargaGrosir1`, `hargaGrosir2`, `hargaGrosir3`, `stok`, `hit`, `qrcodeBarang`, `barcodeBarang`) VALUES (4, '2020-05-10 21:00:53', '958977', 'Tumpat Basi', 'Barang Baik dan Kualitas Oke', '959cf95af4439b8fc381d13ade3acb1f.jpg', 2000, 1900, 1800, 1500, 929, 0, '958977-tumpat-basi-.png', '958977-tumpat-basi-.jpg');
INSERT INTO `barang` (`idBarang`, `tanggalBarang`, `kodeBarang`, `namaBarang`, `keterangan`, `gambar`, `hargaJual`, `hargaGrosir1`, `hargaGrosir2`, `hargaGrosir3`, `stok`, `hit`, `qrcodeBarang`, `barcodeBarang`) VALUES (5, '2020-05-10 21:16:35', 'K99997', 'Karungan Mas', 'Oke dan mantap', 'f1fe2698badb36450673ee5d40330f72.jpg', 9000, 8000, 7000, 7000, 992, 0, 'K99997-karungan-mas-.png', 'K99997-karungan-mas-.jpg');
INSERT INTO `barang` (`idBarang`, `tanggalBarang`, `kodeBarang`, `namaBarang`, `keterangan`, `gambar`, `hargaJual`, `hargaGrosir1`, `hargaGrosir2`, `hargaGrosir3`, `stok`, `hit`, `qrcodeBarang`, `barcodeBarang`) VALUES (6, '2020-05-15 23:17:08', 'LK0099', 'Sepeda Meni', 'Bagus', '4d330f7236aeb5362b00a8b41aa55903.png', 10000, 9000, 8000, 7000, 90, 0, 'LK0099-sepeda-meni-.png', 'LK0099-sepeda-meni-.jpg');
INSERT INTO `barang` (`idBarang`, `tanggalBarang`, `kodeBarang`, `namaBarang`, `keterangan`, `gambar`, `hargaJual`, `hargaGrosir1`, `hargaGrosir2`, `hargaGrosir3`, `stok`, `hit`, `qrcodeBarang`, `barcodeBarang`) VALUES (7, '2020-05-18 06:12:24', '11111', 'Baju Bagus1', 'Oke Banget', '', 3000, 2000, 2000, 2000, 76, 0, '11111-baju-bagus1-.png', '11111-baju-bagus1-.jpg');
INSERT INTO `barang` (`idBarang`, `tanggalBarang`, `kodeBarang`, `namaBarang`, `keterangan`, `gambar`, `hargaJual`, `hargaGrosir1`, `hargaGrosir2`, `hargaGrosir3`, `stok`, `hit`, `qrcodeBarang`, `barcodeBarang`) VALUES (8, '2020-05-18 06:12:24', '11112', 'Baju Bagus2', 'Oke Banget', '', 3000, 2000, 2000, 2000, 73, 0, '11112-baju-bagus2-.png', '11112-baju-bagus2-.jpg');
INSERT INTO `barang` (`idBarang`, `tanggalBarang`, `kodeBarang`, `namaBarang`, `keterangan`, `gambar`, `hargaJual`, `hargaGrosir1`, `hargaGrosir2`, `hargaGrosir3`, `stok`, `hit`, `qrcodeBarang`, `barcodeBarang`) VALUES (9, '2020-05-18 06:12:24', '11113', 'Baju Bagus3', 'Oke Banget', '', 3000, 2000, 2000, 2000, 86, 0, '11113-baju-bagus3-.png', '11113-baju-bagus3-.jpg');
INSERT INTO `barang` (`idBarang`, `tanggalBarang`, `kodeBarang`, `namaBarang`, `keterangan`, `gambar`, `hargaJual`, `hargaGrosir1`, `hargaGrosir2`, `hargaGrosir3`, `stok`, `hit`, `qrcodeBarang`, `barcodeBarang`) VALUES (10, '2020-05-18 06:12:24', '11114', 'Baju Bagus4', 'Oke Banget', '', 3000, 2000, 2000, 2000, 88, 0, '11114-baju-bagus4-.png', '11114-baju-bagus4-.jpg');
INSERT INTO `barang` (`idBarang`, `tanggalBarang`, `kodeBarang`, `namaBarang`, `keterangan`, `gambar`, `hargaJual`, `hargaGrosir1`, `hargaGrosir2`, `hargaGrosir3`, `stok`, `hit`, `qrcodeBarang`, `barcodeBarang`) VALUES (11, '2020-05-18 06:12:24', '11115', 'Baju Bagus5', 'Oke Banget', '', 3000, 2000, 2000, 2000, 87, 0, '11115-baju-bagus5-.png', '11115-baju-bagus5-.jpg');
INSERT INTO `barang` (`idBarang`, `tanggalBarang`, `kodeBarang`, `namaBarang`, `keterangan`, `gambar`, `hargaJual`, `hargaGrosir1`, `hargaGrosir2`, `hargaGrosir3`, `stok`, `hit`, `qrcodeBarang`, `barcodeBarang`) VALUES (12, '2020-05-18 06:12:25', '11116', 'Baju Bagus6', 'Oke Banget', '', 3000, 2000, 2000, 2000, 95, 0, '11116-baju-bagus6-.png', '11116-baju-bagus6-.jpg');
INSERT INTO `barang` (`idBarang`, `tanggalBarang`, `kodeBarang`, `namaBarang`, `keterangan`, `gambar`, `hargaJual`, `hargaGrosir1`, `hargaGrosir2`, `hargaGrosir3`, `stok`, `hit`, `qrcodeBarang`, `barcodeBarang`) VALUES (13, '2020-05-18 06:12:25', '11117', 'Baju Bagus7', 'Oke Banget', '', 3000, 2000, 2000, 2000, 96, 0, '11117-baju-bagus7-.png', '879899-intan-.jpg');
INSERT INTO `barang` (`idBarang`, `tanggalBarang`, `kodeBarang`, `namaBarang`, `keterangan`, `gambar`, `hargaJual`, `hargaGrosir1`, `hargaGrosir2`, `hargaGrosir3`, `stok`, `hit`, `qrcodeBarang`, `barcodeBarang`) VALUES (14, '2020-05-18 06:12:25', '11118', 'Baju Bagus8', 'Oke Banget', '', 3000, 2000, 2000, 2000, 100, 0, '11118-baju-bagus8-.png', '879900-permata-.jpg');
INSERT INTO `barang` (`idBarang`, `tanggalBarang`, `kodeBarang`, `namaBarang`, `keterangan`, `gambar`, `hargaJual`, `hargaGrosir1`, `hargaGrosir2`, `hargaGrosir3`, `stok`, `hit`, `qrcodeBarang`, `barcodeBarang`) VALUES (15, '2020-05-18 06:12:25', '11119', 'Baju Bagus9', 'Oke Banget', '', 3000, 2000, 2000, 2000, 100, 0, 'Kl879901-besi-.png', 'Kl879901-besi-.jpg');
INSERT INTO `barang` (`idBarang`, `tanggalBarang`, `kodeBarang`, `namaBarang`, `keterangan`, `gambar`, `hargaJual`, `hargaGrosir1`, `hargaGrosir2`, `hargaGrosir3`, `stok`, `hit`, `qrcodeBarang`, `barcodeBarang`) VALUES (16, '2020-05-18 06:12:25', '11120', 'Baju Bagus10', 'Oke Banget', '', 3000, 2000, 2000, 2000, 100, 0, '11120-baju-bagus10-.png', '11120-baju-bagus10-.jpg');
INSERT INTO `barang` (`idBarang`, `tanggalBarang`, `kodeBarang`, `namaBarang`, `keterangan`, `gambar`, `hargaJual`, `hargaGrosir1`, `hargaGrosir2`, `hargaGrosir3`, `stok`, `hit`, `qrcodeBarang`, `barcodeBarang`) VALUES (17, '2020-05-18 06:12:25', '11157', 'Baju Bagus11', 'Oke Banget', '', 3000, 2000, 2000, 2000, 100, 0, '11157-baju-bagus11-.png', '11157-baju-bagus11-.jpg');
INSERT INTO `barang` (`idBarang`, `tanggalBarang`, `kodeBarang`, `namaBarang`, `keterangan`, `gambar`, `hargaJual`, `hargaGrosir1`, `hargaGrosir2`, `hargaGrosir3`, `stok`, `hit`, `qrcodeBarang`, `barcodeBarang`) VALUES (18, '2020-05-21 20:51:05', '10000', 'Coba coba', 'Bagus', '26a62ceebc3f42e06b8fafca72a03277.png', 9000, 8000, 7000, 6000, 10, 0, '10000-coba-coba-.png', '10000-coba-coba-.jpg');
INSERT INTO `barang` (`idBarang`, `tanggalBarang`, `kodeBarang`, `namaBarang`, `keterangan`, `gambar`, `hargaJual`, `hargaGrosir1`, `hargaGrosir2`, `hargaGrosir3`, `stok`, `hit`, `qrcodeBarang`, `barcodeBarang`) VALUES (19, '2020-05-21 20:53:33', '100949', 'Coba lagi bro', 'bagus', 'f1fc797679190b2e19102525a60d0b72.png', 8000, 8000, 7000, 6000, 29, 0, '100949-coba-lagi-bro-.png', '100949-coba-lagi-bro-.jpg');
INSERT INTO `barang` (`idBarang`, `tanggalBarang`, `kodeBarang`, `namaBarang`, `keterangan`, `gambar`, `hargaJual`, `hargaGrosir1`, `hargaGrosir2`, `hargaGrosir3`, `stok`, `hit`, `qrcodeBarang`, `barcodeBarang`) VALUES (20, '2020-07-09 01:27:28', '6876876', '6iyiy', 'oiyiy', 'f1ea750299e4a5cfa63a0d86f6806287.jpg', 777, 777, 77, 77, 77, 0, '6876876-6iyiy-.png', '6876876-6iyiy-.jpg');
INSERT INTO `barang` (`idBarang`, `tanggalBarang`, `kodeBarang`, `namaBarang`, `keterangan`, `gambar`, `hargaJual`, `hargaGrosir1`, `hargaGrosir2`, `hargaGrosir3`, `stok`, `hit`, `qrcodeBarang`, `barcodeBarang`) VALUES (21, '2020-07-13 18:53:04', '687', '87687', '87678', 'ae8a263b2c7bd05531e586c0b52a274a.jpg', 87687, 87687, 87687, 86, 876, 0, '687-87687-.png', '687-87687-.jpg');


#
# TABLE STRUCTURE FOR: admin
#

DROP TABLE IF EXISTS `admin`;

CREATE TABLE `admin` (
  `idAdmin` int(11) NOT NULL AUTO_INCREMENT,
  `namaLengkap` varchar(250) NOT NULL,
  `usernameAdmin` varchar(100) NOT NULL,
  `passwordAdmin` varchar(100) NOT NULL,
  PRIMARY KEY (`idAdmin`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4;

INSERT INTO `admin` (`idAdmin`, `namaLengkap`, `usernameAdmin`, `passwordAdmin`) VALUES (1, 'El Firmasyah', 'firman', '21232f297a57a5a743894a0e4a801fc3');


#
# TABLE STRUCTURE FOR: bahankeluar
#

DROP TABLE IF EXISTS `bahankeluar`;

CREATE TABLE `bahankeluar` (
  `idBahanKeluar` int(11) NOT NULL AUTO_INCREMENT,
  `noTransaksiKeluar` varchar(100) NOT NULL,
  `idDetailOrdersKeluar` int(11) NOT NULL,
  `idBahanMasukKeluar` int(11) NOT NULL,
  `qtyKeluar` int(11) NOT NULL,
  `namaBahanOrderanKeluar` varchar(200) NOT NULL,
  `hargaOrderanKeluar` int(11) NOT NULL,
  `idSuplayerKeluar` int(11) NOT NULL,
  `tanggalTransaksi` timestamp NOT NULL DEFAULT current_timestamp(),
  `identitasOrderan` text NOT NULL,
  `keteranganBahanKeluar` enum('ongkosan','orderan') NOT NULL,
  `statusBahanKeluar` enum('Fix','Reject') NOT NULL,
  `qtyRejectKeluar` int(5) NOT NULL,
  `potonganOrderan` int(11) NOT NULL,
  `keteranganOrderan` text NOT NULL,
  PRIMARY KEY (`idBahanKeluar`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4;

INSERT INTO `bahankeluar` (`idBahanKeluar`, `noTransaksiKeluar`, `idDetailOrdersKeluar`, `idBahanMasukKeluar`, `qtyKeluar`, `namaBahanOrderanKeluar`, `hargaOrderanKeluar`, `idSuplayerKeluar`, `tanggalTransaksi`, `identitasOrderan`, `keteranganBahanKeluar`, `statusBahanKeluar`, `qtyRejectKeluar`, `potonganOrderan`, `keteranganOrderan`) VALUES (1, '120001', 2, 12, 20, '', 0, 2, '2020-06-25 05:32:43', '', 'ongkosan', 'Reject', 10, 0, '');
INSERT INTO `bahankeluar` (`idBahanKeluar`, `noTransaksiKeluar`, `idDetailOrdersKeluar`, `idBahanMasukKeluar`, `qtyKeluar`, `namaBahanOrderanKeluar`, `hargaOrderanKeluar`, `idSuplayerKeluar`, `tanggalTransaksi`, `identitasOrderan`, `keteranganBahanKeluar`, `statusBahanKeluar`, `qtyRejectKeluar`, `potonganOrderan`, `keteranganOrderan`) VALUES (2, '120001', 2, 12, 10, '', 0, 6, '2020-06-25 05:33:00', '', 'ongkosan', 'Fix', 0, 0, '');
INSERT INTO `bahankeluar` (`idBahanKeluar`, `noTransaksiKeluar`, `idDetailOrdersKeluar`, `idBahanMasukKeluar`, `qtyKeluar`, `namaBahanOrderanKeluar`, `hargaOrderanKeluar`, `idSuplayerKeluar`, `tanggalTransaksi`, `identitasOrderan`, `keteranganBahanKeluar`, `statusBahanKeluar`, `qtyRejectKeluar`, `potonganOrderan`, `keteranganOrderan`) VALUES (3, '120001', 1, 0, 10, 'Bluset Basi', 1000, 3, '2020-06-25 05:33:37', 'NTT', 'orderan', 'Fix', 0, 0, '');
INSERT INTO `bahankeluar` (`idBahanKeluar`, `noTransaksiKeluar`, `idDetailOrdersKeluar`, `idBahanMasukKeluar`, `qtyKeluar`, `namaBahanOrderanKeluar`, `hargaOrderanKeluar`, `idSuplayerKeluar`, `tanggalTransaksi`, `identitasOrderan`, `keteranganBahanKeluar`, `statusBahanKeluar`, `qtyRejectKeluar`, `potonganOrderan`, `keteranganOrderan`) VALUES (4, '120003', 6, 6, 20, '', 0, 6, '2020-06-25 06:11:44', '', 'ongkosan', 'Fix', 0, 0, '');
INSERT INTO `bahankeluar` (`idBahanKeluar`, `noTransaksiKeluar`, `idDetailOrdersKeluar`, `idBahanMasukKeluar`, `qtyKeluar`, `namaBahanOrderanKeluar`, `hargaOrderanKeluar`, `idSuplayerKeluar`, `tanggalTransaksi`, `identitasOrderan`, `keteranganBahanKeluar`, `statusBahanKeluar`, `qtyRejectKeluar`, `potonganOrderan`, `keteranganOrderan`) VALUES (5, '120003', 6, 12, 100, '', 0, 6, '2020-06-25 06:12:01', '', 'ongkosan', 'Fix', 0, 0, '');
INSERT INTO `bahankeluar` (`idBahanKeluar`, `noTransaksiKeluar`, `idDetailOrdersKeluar`, `idBahanMasukKeluar`, `qtyKeluar`, `namaBahanOrderanKeluar`, `hargaOrderanKeluar`, `idSuplayerKeluar`, `tanggalTransaksi`, `identitasOrderan`, `keteranganBahanKeluar`, `statusBahanKeluar`, `qtyRejectKeluar`, `potonganOrderan`, `keteranganOrderan`) VALUES (6, '120003', 5, 0, 100, 'Nano Basi', 1800, 3, '2020-06-25 06:12:47', 'NTT', 'orderan', 'Fix', 0, 9000, 'Cek cek');
INSERT INTO `bahankeluar` (`idBahanKeluar`, `noTransaksiKeluar`, `idDetailOrdersKeluar`, `idBahanMasukKeluar`, `qtyKeluar`, `namaBahanOrderanKeluar`, `hargaOrderanKeluar`, `idSuplayerKeluar`, `tanggalTransaksi`, `identitasOrderan`, `keteranganBahanKeluar`, `statusBahanKeluar`, `qtyRejectKeluar`, `potonganOrderan`, `keteranganOrderan`) VALUES (7, '120002', 4, 6, 20, '', 0, 2, '2020-06-25 18:45:50', '', 'ongkosan', 'Reject', 10, 0, '');
INSERT INTO `bahankeluar` (`idBahanKeluar`, `noTransaksiKeluar`, `idDetailOrdersKeluar`, `idBahanMasukKeluar`, `qtyKeluar`, `namaBahanOrderanKeluar`, `hargaOrderanKeluar`, `idSuplayerKeluar`, `tanggalTransaksi`, `identitasOrderan`, `keteranganBahanKeluar`, `statusBahanKeluar`, `qtyRejectKeluar`, `potonganOrderan`, `keteranganOrderan`) VALUES (8, '120002', 3, 0, 100, 'barang coba 1', 100, 3, '2020-06-25 18:46:16', 'NTT', 'orderan', 'Fix', 0, 9000, 'Oke');


#
# TABLE STRUCTURE FOR: bahanmasuk
#

DROP TABLE IF EXISTS `bahanmasuk`;

CREATE TABLE `bahanmasuk` (
  `idBahanMasuk` int(11) NOT NULL AUTO_INCREMENT,
  `tanggalBahanMasuk` date NOT NULL,
  `kodeBahanMasuk` varchar(50) NOT NULL,
  `namaBahanMasuk` varchar(200) NOT NULL,
  `hargaBeliMasuk` int(11) NOT NULL,
  `stockMasuk` int(11) NOT NULL,
  `qrcodeBahan` varchar(100) NOT NULL,
  `barcodeBahan` varchar(100) NOT NULL,
  PRIMARY KEY (`idBahanMasuk`)
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8mb4;

INSERT INTO `bahanmasuk` (`idBahanMasuk`, `tanggalBahanMasuk`, `kodeBahanMasuk`, `namaBahanMasuk`, `hargaBeliMasuk`, `stockMasuk`, `qrcodeBahan`, `barcodeBahan`) VALUES (6, '2020-04-20', '879897', 'Kerang Mas', 2000, 757, '879897-kerang-mas-.png', '879897-kerang-mas-.jpg');
INSERT INTO `bahanmasuk` (`idBahanMasuk`, `tanggalBahanMasuk`, `kodeBahanMasuk`, `namaBahanMasuk`, `hargaBeliMasuk`, `stockMasuk`, `qrcodeBahan`, `barcodeBahan`) VALUES (12, '2020-04-21', '879898', 'Kerang Abu', 1000, 370, '879898-kerang-abu-.png', '879898-kerang-abu-.jpg');
INSERT INTO `bahanmasuk` (`idBahanMasuk`, `tanggalBahanMasuk`, `kodeBahanMasuk`, `namaBahanMasuk`, `hargaBeliMasuk`, `stockMasuk`, `qrcodeBahan`, `barcodeBahan`) VALUES (13, '2020-04-22', '879899', 'Intan', 2000, 418, '879899-intan-.png', '879899-intan-.jpg');
INSERT INTO `bahanmasuk` (`idBahanMasuk`, `tanggalBahanMasuk`, `kodeBahanMasuk`, `namaBahanMasuk`, `hargaBeliMasuk`, `stockMasuk`, `qrcodeBahan`, `barcodeBahan`) VALUES (14, '2020-04-23', '879900', 'Permata', 100, 880, '879900-permata-.png', '879900-permata-.jpg');
INSERT INTO `bahanmasuk` (`idBahanMasuk`, `tanggalBahanMasuk`, `kodeBahanMasuk`, `namaBahanMasuk`, `hargaBeliMasuk`, `stockMasuk`, `qrcodeBahan`, `barcodeBahan`) VALUES (15, '2020-04-24', 'Kl879901', 'Besi', 100, 363, 'Kl879901-besi-.png', 'Kl879901-besi-.jpg');


#
# TABLE STRUCTURE FOR: bot
#

DROP TABLE IF EXISTS `bot`;

CREATE TABLE `bot` (
  `idBot` int(11) NOT NULL AUTO_INCREMENT,
  `chatID` varchar(50) NOT NULL,
  `namaTelegram` varchar(200) NOT NULL,
  PRIMARY KEY (`idBot`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4;

INSERT INTO `bot` (`idBot`, `chatID`, `namaTelegram`) VALUES (4, '341441191', 'Moh. Ainol Yaqin');
INSERT INTO `bot` (`idBot`, `chatID`, `namaTelegram`) VALUES (5, '1123445', 'Firman Syah');


#
# TABLE STRUCTURE FOR: costumers
#

DROP TABLE IF EXISTS `costumers`;

CREATE TABLE `costumers` (
  `idCostumers` int(11) NOT NULL AUTO_INCREMENT,
  `namaCostumers` varchar(200) NOT NULL,
  `alamatCostumers` text NOT NULL,
  `tlpCostumers` char(12) NOT NULL,
  `shippingAgent` varchar(100) NOT NULL,
  PRIMARY KEY (`idCostumers`)
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8mb4;

INSERT INTO `costumers` (`idCostumers`, `namaCostumers`, `alamatCostumers`, `tlpCostumers`, `shippingAgent`) VALUES (2, 'Napa Dandan', 'Paiton', '086555444289', '');
INSERT INTO `costumers` (`idCostumers`, `namaCostumers`, `alamatCostumers`, `tlpCostumers`, `shippingAgent`) VALUES (3, 'Bambang Tamvan', 'NTT', '08555555', '');
INSERT INTO `costumers` (`idCostumers`, `namaCostumers`, `alamatCostumers`, `tlpCostumers`, `shippingAgent`) VALUES (4, 'Deni Sulaiman', 'Pajarakan', '081223654876', '');
INSERT INTO `costumers` (`idCostumers`, `namaCostumers`, `alamatCostumers`, `tlpCostumers`, `shippingAgent`) VALUES (5, 'Adeliah Manda', 'Paiton', '087234656767', '');
INSERT INTO `costumers` (`idCostumers`, `namaCostumers`, `alamatCostumers`, `tlpCostumers`, `shippingAgent`) VALUES (6, 'Nanang', 'Pai', '9808908', '');
INSERT INTO `costumers` (`idCostumers`, `namaCostumers`, `alamatCostumers`, `tlpCostumers`, `shippingAgent`) VALUES (7, 'Tes 3', 'Paiton', '3433333', '');
INSERT INTO `costumers` (`idCostumers`, `namaCostumers`, `alamatCostumers`, `tlpCostumers`, `shippingAgent`) VALUES (8, 'Tes3', 'Paiton', '3433333', '');
INSERT INTO `costumers` (`idCostumers`, `namaCostumers`, `alamatCostumers`, `tlpCostumers`, `shippingAgent`) VALUES (9, 'tesss4', 'fdsfds', '767', '');
INSERT INTO `costumers` (`idCostumers`, `namaCostumers`, `alamatCostumers`, `tlpCostumers`, `shippingAgent`) VALUES (10, 'Mr Brown', 'USA', '081333222111', 'Op');
INSERT INTO `costumers` (`idCostumers`, `namaCostumers`, `alamatCostumers`, `tlpCostumers`, `shippingAgent`) VALUES (11, 'Shipping Agent', 'Paiton', '081123987367', '');
INSERT INTO `costumers` (`idCostumers`, `namaCostumers`, `alamatCostumers`, `tlpCostumers`, `shippingAgent`) VALUES (12, 'dddd', '22222', '', '');


#
# TABLE STRUCTURE FOR: detailorders
#

DROP TABLE IF EXISTS `detailorders`;

CREATE TABLE `detailorders` (
  `idDetailOrders` int(11) NOT NULL AUTO_INCREMENT,
  `noTransaksiDetail` varchar(150) NOT NULL,
  `idKaryawanDetail` int(11) NOT NULL,
  `idBarangDetail` int(11) NOT NULL,
  `qtyDetail` int(11) NOT NULL,
  `hargaDetail` int(50) NOT NULL,
  `deskripsiDetail` text NOT NULL,
  `barangDetailKosong` varchar(150) NOT NULL,
  `kodeDetailOrderKosong` varchar(100) NOT NULL,
  `gambarDetailKosong` varchar(200) NOT NULL,
  PRIMARY KEY (`idDetailOrders`)
) ENGINE=InnoDB AUTO_INCREMENT=59 DEFAULT CHARSET=utf8mb4;

INSERT INTO `detailorders` (`idDetailOrders`, `noTransaksiDetail`, `idKaryawanDetail`, `idBarangDetail`, `qtyDetail`, `hargaDetail`, `deskripsiDetail`, `barangDetailKosong`, `kodeDetailOrderKosong`, `gambarDetailKosong`) VALUES (1, '120001', 12, 2, 10, 2000, 'Deskripsi Bro 1', '', '', '');
INSERT INTO `detailorders` (`idDetailOrders`, `noTransaksiDetail`, `idKaryawanDetail`, `idBarangDetail`, `qtyDetail`, `hargaDetail`, `deskripsiDetail`, `barangDetailKosong`, `kodeDetailOrderKosong`, `gambarDetailKosong`) VALUES (2, '120001', 12, 3, 20, 10000, 'Deskripsi bro 2', '', '', '');
INSERT INTO `detailorders` (`idDetailOrders`, `noTransaksiDetail`, `idKaryawanDetail`, `idBarangDetail`, `qtyDetail`, `hargaDetail`, `deskripsiDetail`, `barangDetailKosong`, `kodeDetailOrderKosong`, `gambarDetailKosong`) VALUES (3, '120002', 12, 0, 100, 1000, 'Deskribsi coba 1', 'barang coba 1', '123', '12900301406c014d6ea22bb513b73dd9.png');
INSERT INTO `detailorders` (`idDetailOrders`, `noTransaksiDetail`, `idKaryawanDetail`, `idBarangDetail`, `qtyDetail`, `hargaDetail`, `deskripsiDetail`, `barangDetailKosong`, `kodeDetailOrderKosong`, `gambarDetailKosong`) VALUES (4, '120002', 12, 0, 10, 9000, 'Deskribsi coba 2', 'barang coba 2', '124', '');
INSERT INTO `detailorders` (`idDetailOrders`, `noTransaksiDetail`, `idKaryawanDetail`, `idBarangDetail`, `qtyDetail`, `hargaDetail`, `deskripsiDetail`, `barangDetailKosong`, `kodeDetailOrderKosong`, `gambarDetailKosong`) VALUES (5, '120003', 12, 3, 100, 2000, 'Uji deskripsi', '', '', '');
INSERT INTO `detailorders` (`idDetailOrders`, `noTransaksiDetail`, `idKaryawanDetail`, `idBarangDetail`, `qtyDetail`, `hargaDetail`, `deskripsiDetail`, `barangDetailKosong`, `kodeDetailOrderKosong`, `gambarDetailKosong`) VALUES (6, '120003', 12, 4, 200, 2000, 'Uji Deskrips', '', '', '');
INSERT INTO `detailorders` (`idDetailOrders`, `noTransaksiDetail`, `idKaryawanDetail`, `idBarangDetail`, `qtyDetail`, `hargaDetail`, `deskripsiDetail`, `barangDetailKosong`, `kodeDetailOrderKosong`, `gambarDetailKosong`) VALUES (7, '120004', 12, 0, 666, 7777, '666', '666', '677', '422a42297b53c2ebc2e9b53be3590a1b.jpeg');
INSERT INTO `detailorders` (`idDetailOrders`, `noTransaksiDetail`, `idKaryawanDetail`, `idBarangDetail`, `qtyDetail`, `hargaDetail`, `deskripsiDetail`, `barangDetailKosong`, `kodeDetailOrderKosong`, `gambarDetailKosong`) VALUES (8, '120004', 12, 0, 9798, 77777, '9798', '98798', '8678', '552ea752350e84af8e31f1a687a9ce5c.jpeg');
INSERT INTO `detailorders` (`idDetailOrders`, `noTransaksiDetail`, `idKaryawanDetail`, `idBarangDetail`, `qtyDetail`, `hargaDetail`, `deskripsiDetail`, `barangDetailKosong`, `kodeDetailOrderKosong`, `gambarDetailKosong`) VALUES (9, '120004', 12, 0, 88, 88888, 'iyiuiyiu', 'iuyui', '9879', 'cfb031c2ad27193394fa56864cf880e2.jpeg');
INSERT INTO `detailorders` (`idDetailOrders`, `noTransaksiDetail`, `idKaryawanDetail`, `idBarangDetail`, `qtyDetail`, `hargaDetail`, `deskripsiDetail`, `barangDetailKosong`, `kodeDetailOrderKosong`, `gambarDetailKosong`) VALUES (10, '120004', 12, 0, 97987, 97987, '979', '86876', '876', '35915a53b9f55c330f41c72e56ee51ab.jpg');
INSERT INTO `detailorders` (`idDetailOrders`, `noTransaksiDetail`, `idKaryawanDetail`, `idBarangDetail`, `qtyDetail`, `hargaDetail`, `deskripsiDetail`, `barangDetailKosong`, `kodeDetailOrderKosong`, `gambarDetailKosong`) VALUES (11, '120004', 12, 0, 876876, 86876, '86876', '86876', '86876', 'f565459b5e64e0d5679890dccc0d593a.JPG');
INSERT INTO `detailorders` (`idDetailOrders`, `noTransaksiDetail`, `idKaryawanDetail`, `idBarangDetail`, `qtyDetail`, `hargaDetail`, `deskripsiDetail`, `barangDetailKosong`, `kodeDetailOrderKosong`, `gambarDetailKosong`) VALUES (12, '120005', 12, 0, 979, 87987, 'iyi', 'yiy', '8768', 'd841341c1c1e3360e09728f6e624b62c.jpg');
INSERT INTO `detailorders` (`idDetailOrders`, `noTransaksiDetail`, `idKaryawanDetail`, `idBarangDetail`, `qtyDetail`, `hargaDetail`, `deskripsiDetail`, `barangDetailKosong`, `kodeDetailOrderKosong`, `gambarDetailKosong`) VALUES (13, '120006', 12, 0, 87686, 98768, '86876', '86876', '876', '35cebb74cebf69f79badf9db1fa82c65.jpg');
INSERT INTO `detailorders` (`idDetailOrders`, `noTransaksiDetail`, `idKaryawanDetail`, `idBarangDetail`, `qtyDetail`, `hargaDetail`, `deskripsiDetail`, `barangDetailKosong`, `kodeDetailOrderKosong`, `gambarDetailKosong`) VALUES (14, '120006', 12, 0, 97987, 7000, '97987', '97987', '98798', 'f76b493e03454c027c3976a93c7ccfe4.JPG');
INSERT INTO `detailorders` (`idDetailOrders`, `noTransaksiDetail`, `idKaryawanDetail`, `idBarangDetail`, `qtyDetail`, `hargaDetail`, `deskripsiDetail`, `barangDetailKosong`, `kodeDetailOrderKosong`, `gambarDetailKosong`) VALUES (15, '120006', 12, 0, 8, 9879, '9798', '97897', '6876', '6d3fa039f91c7e678b1f00693ff19da7.JPG');
INSERT INTO `detailorders` (`idDetailOrders`, `noTransaksiDetail`, `idKaryawanDetail`, `idBarangDetail`, `qtyDetail`, `hargaDetail`, `deskripsiDetail`, `barangDetailKosong`, `kodeDetailOrderKosong`, `gambarDetailKosong`) VALUES (16, '120007', 12, 0, 7987, 80000, '97987', '97987', '9798', '7057f5cd6d60c7b15adabcfc210c5aec.JPG');
INSERT INTO `detailorders` (`idDetailOrders`, `noTransaksiDetail`, `idKaryawanDetail`, `idBarangDetail`, `qtyDetail`, `hargaDetail`, `deskripsiDetail`, `barangDetailKosong`, `kodeDetailOrderKosong`, `gambarDetailKosong`) VALUES (17, '120007', 12, 0, 8686, 8686, '86876', '76876', '8687', 'aace14deb9b740c6f6fa4e8e9fa69fac.JPG');
INSERT INTO `detailorders` (`idDetailOrders`, `noTransaksiDetail`, `idKaryawanDetail`, `idBarangDetail`, `qtyDetail`, `hargaDetail`, `deskripsiDetail`, `barangDetailKosong`, `kodeDetailOrderKosong`, `gambarDetailKosong`) VALUES (18, '120007', 12, 0, 7, 777, 'iuyiuy', 'iyiy', 'iuyiu', 'edf7e9d5fcc4c1f95601d281b36df762.JPG');
INSERT INTO `detailorders` (`idDetailOrders`, `noTransaksiDetail`, `idKaryawanDetail`, `idBarangDetail`, `qtyDetail`, `hargaDetail`, `deskripsiDetail`, `barangDetailKosong`, `kodeDetailOrderKosong`, `gambarDetailKosong`) VALUES (19, '120007', 12, 0, 88, 88, '888', '888', '7888', '20264673c81412955092b3ada1218950.JPG');
INSERT INTO `detailorders` (`idDetailOrders`, `noTransaksiDetail`, `idKaryawanDetail`, `idBarangDetail`, `qtyDetail`, `hargaDetail`, `deskripsiDetail`, `barangDetailKosong`, `kodeDetailOrderKosong`, `gambarDetailKosong`) VALUES (20, '120007', 12, 0, 9798, 9798, '97987', '987987', '97897', '4bcb32c952ca63b9cc3ba01f2383d2d7.JPG');
INSERT INTO `detailorders` (`idDetailOrders`, `noTransaksiDetail`, `idKaryawanDetail`, `idBarangDetail`, `qtyDetail`, `hargaDetail`, `deskripsiDetail`, `barangDetailKosong`, `kodeDetailOrderKosong`, `gambarDetailKosong`) VALUES (21, '120007', 12, 0, 7676, 7676, '86876', '86876', '8687', 'ecef77ad81d20bf310b96679592d4f97.JPG');
INSERT INTO `detailorders` (`idDetailOrders`, `noTransaksiDetail`, `idKaryawanDetail`, `idBarangDetail`, `qtyDetail`, `hargaDetail`, `deskripsiDetail`, `barangDetailKosong`, `kodeDetailOrderKosong`, `gambarDetailKosong`) VALUES (22, '120007', 12, 0, 8768, 868, '87687', '8687', '87687', '1d60fd948ce751b6c1d049411247bd58.JPG');
INSERT INTO `detailorders` (`idDetailOrders`, `noTransaksiDetail`, `idKaryawanDetail`, `idBarangDetail`, `qtyDetail`, `hargaDetail`, `deskripsiDetail`, `barangDetailKosong`, `kodeDetailOrderKosong`, `gambarDetailKosong`) VALUES (23, '120007', 12, 0, 7, 88, '9798', '979', '8978', '166db7bfedb7c301058dde52137a318d.jpg');
INSERT INTO `detailorders` (`idDetailOrders`, `noTransaksiDetail`, `idKaryawanDetail`, `idBarangDetail`, `qtyDetail`, `hargaDetail`, `deskripsiDetail`, `barangDetailKosong`, `kodeDetailOrderKosong`, `gambarDetailKosong`) VALUES (24, '120008', 12, 0, 77, 7777, '8687', '8687', '876', '456bc41837e1ec4e1b61cc1efde9ba32.JPG');
INSERT INTO `detailorders` (`idDetailOrders`, `noTransaksiDetail`, `idKaryawanDetail`, `idBarangDetail`, `qtyDetail`, `hargaDetail`, `deskripsiDetail`, `barangDetailKosong`, `kodeDetailOrderKosong`, `gambarDetailKosong`) VALUES (25, '120008', 12, 0, 979, 900, '98798', '98798', '98789', '631281b0834acee4009d159f0863cc43.JPG');
INSERT INTO `detailorders` (`idDetailOrders`, `noTransaksiDetail`, `idKaryawanDetail`, `idBarangDetail`, `qtyDetail`, `hargaDetail`, `deskripsiDetail`, `barangDetailKosong`, `kodeDetailOrderKosong`, `gambarDetailKosong`) VALUES (26, '120008', 12, 0, 8, 9000, '868', '87678', '876', '0ad0f42ff35306a77d8a412c2fa8d967.JPG');
INSERT INTO `detailorders` (`idDetailOrders`, `noTransaksiDetail`, `idKaryawanDetail`, `idBarangDetail`, `qtyDetail`, `hargaDetail`, `deskripsiDetail`, `barangDetailKosong`, `kodeDetailOrderKosong`, `gambarDetailKosong`) VALUES (27, '120009', 12, 0, 9, 9999, '999', '888', '8', '07eeb72b3eec27bfe5b0ca5cd8bdca9f.JPG');
INSERT INTO `detailorders` (`idDetailOrders`, `noTransaksiDetail`, `idKaryawanDetail`, `idBarangDetail`, `qtyDetail`, `hargaDetail`, `deskripsiDetail`, `barangDetailKosong`, `kodeDetailOrderKosong`, `gambarDetailKosong`) VALUES (28, '120010', 12, 0, 88, 888, '2', '1222', '1233', '9a2e422c11f806857836c1b7a08da154.jpg');
INSERT INTO `detailorders` (`idDetailOrders`, `noTransaksiDetail`, `idKaryawanDetail`, `idBarangDetail`, `qtyDetail`, `hargaDetail`, `deskripsiDetail`, `barangDetailKosong`, `kodeDetailOrderKosong`, `gambarDetailKosong`) VALUES (29, '120010', 12, 0, 9, 899, '89', '98798', '877', '46bcf5c32bd79f0837d3fdd0c505e3db.JPG');
INSERT INTO `detailorders` (`idDetailOrders`, `noTransaksiDetail`, `idKaryawanDetail`, `idBarangDetail`, `qtyDetail`, `hargaDetail`, `deskripsiDetail`, `barangDetailKosong`, `kodeDetailOrderKosong`, `gambarDetailKosong`) VALUES (30, '120010', 12, 0, 687, 99000, '868', '868', '8768', '60d856e95738085f57fd2a2dccd0fe8f.JPG');
INSERT INTO `detailorders` (`idDetailOrders`, `noTransaksiDetail`, `idKaryawanDetail`, `idBarangDetail`, `qtyDetail`, `hargaDetail`, `deskripsiDetail`, `barangDetailKosong`, `kodeDetailOrderKosong`, `gambarDetailKosong`) VALUES (31, '120010', 12, 0, 868, 8687, '8687', '8687', '876', 'e571d7af918e98c152ba6b6b17861690.JPG');
INSERT INTO `detailorders` (`idDetailOrders`, `noTransaksiDetail`, `idKaryawanDetail`, `idBarangDetail`, `qtyDetail`, `hargaDetail`, `deskripsiDetail`, `barangDetailKosong`, `kodeDetailOrderKosong`, `gambarDetailKosong`) VALUES (32, '120011', 12, 0, 7, 8888, '979', '987', 'i8687', '16b164c92f9000ece574d01a050a85ff.JPG');
INSERT INTO `detailorders` (`idDetailOrders`, `noTransaksiDetail`, `idKaryawanDetail`, `idBarangDetail`, `qtyDetail`, `hargaDetail`, `deskripsiDetail`, `barangDetailKosong`, `kodeDetailOrderKosong`, `gambarDetailKosong`) VALUES (33, '120012', 12, 0, 868, 868, '868', '9876786', '87678', '40b3030bca025dc8e2a80bcd5a1a60a8.jpg');
INSERT INTO `detailorders` (`idDetailOrders`, `noTransaksiDetail`, `idKaryawanDetail`, `idBarangDetail`, `qtyDetail`, `hargaDetail`, `deskripsiDetail`, `barangDetailKosong`, `kodeDetailOrderKosong`, `gambarDetailKosong`) VALUES (34, '120013', 12, 0, 868, 868, '868', '9876786', '87678', '40b3030bca025dc8e2a80bcd5a1a60a8.jpg');
INSERT INTO `detailorders` (`idDetailOrders`, `noTransaksiDetail`, `idKaryawanDetail`, `idBarangDetail`, `qtyDetail`, `hargaDetail`, `deskripsiDetail`, `barangDetailKosong`, `kodeDetailOrderKosong`, `gambarDetailKosong`) VALUES (35, '120014', 12, 0, 868, 868, '868', '9876786', '87678', '40b3030bca025dc8e2a80bcd5a1a60a8.jpg');
INSERT INTO `detailorders` (`idDetailOrders`, `noTransaksiDetail`, `idKaryawanDetail`, `idBarangDetail`, `qtyDetail`, `hargaDetail`, `deskripsiDetail`, `barangDetailKosong`, `kodeDetailOrderKosong`, `gambarDetailKosong`) VALUES (36, '120015', 12, 0, 97, 9000, '97', '98798', '897', '337411a7091345c8255199289682a074.JPG');
INSERT INTO `detailorders` (`idDetailOrders`, `noTransaksiDetail`, `idKaryawanDetail`, `idBarangDetail`, `qtyDetail`, `hargaDetail`, `deskripsiDetail`, `barangDetailKosong`, `kodeDetailOrderKosong`, `gambarDetailKosong`) VALUES (37, '120015', 12, 0, 97, 9000, '97', '98798', '897', '337411a7091345c8255199289682a074.JPG');
INSERT INTO `detailorders` (`idDetailOrders`, `noTransaksiDetail`, `idKaryawanDetail`, `idBarangDetail`, `qtyDetail`, `hargaDetail`, `deskripsiDetail`, `barangDetailKosong`, `kodeDetailOrderKosong`, `gambarDetailKosong`) VALUES (38, '120016', 12, 0, 97, 7777, '987', '9798', '897', '11e641a01ca29ebc80dbda2ea36e6be0.jpg');
INSERT INTO `detailorders` (`idDetailOrders`, `noTransaksiDetail`, `idKaryawanDetail`, `idBarangDetail`, `qtyDetail`, `hargaDetail`, `deskripsiDetail`, `barangDetailKosong`, `kodeDetailOrderKosong`, `gambarDetailKosong`) VALUES (39, '120017', 12, 0, 68, 666, '8678', '868', '876', '19fa9f5bab95dc542c4651f0f10900c1.JPG');
INSERT INTO `detailorders` (`idDetailOrders`, `noTransaksiDetail`, `idKaryawanDetail`, `idBarangDetail`, `qtyDetail`, `hargaDetail`, `deskripsiDetail`, `barangDetailKosong`, `kodeDetailOrderKosong`, `gambarDetailKosong`) VALUES (40, '120018', 12, 0, 12, 1000, 'Box 23 Tkk', 'barang coba', '1234', '37f005cc8105501dcb3c7123cd9d9065.jpg');
INSERT INTO `detailorders` (`idDetailOrders`, `noTransaksiDetail`, `idKaryawanDetail`, `idBarangDetail`, `qtyDetail`, `hargaDetail`, `deskripsiDetail`, `barangDetailKosong`, `kodeDetailOrderKosong`, `gambarDetailKosong`) VALUES (41, '120019', 12, 0, 3, 2, '3', '2', '1', '0bdb5ec6c9f89e273c0ddda1b29b2b08.jpg');
INSERT INTO `detailorders` (`idDetailOrders`, `noTransaksiDetail`, `idKaryawanDetail`, `idBarangDetail`, `qtyDetail`, `hargaDetail`, `deskripsiDetail`, `barangDetailKosong`, `kodeDetailOrderKosong`, `gambarDetailKosong`) VALUES (42, '120019', 12, 0, 8, 86876, '8687', '8768', '8768', '0241992b2917d969d40e4b068d962bbc.jpg');
INSERT INTO `detailorders` (`idDetailOrders`, `noTransaksiDetail`, `idKaryawanDetail`, `idBarangDetail`, `qtyDetail`, `hargaDetail`, `deskripsiDetail`, `barangDetailKosong`, `kodeDetailOrderKosong`, `gambarDetailKosong`) VALUES (43, '120020', 12, 0, 3, 2, '3', '2', '1', '0bdb5ec6c9f89e273c0ddda1b29b2b08.jpg');
INSERT INTO `detailorders` (`idDetailOrders`, `noTransaksiDetail`, `idKaryawanDetail`, `idBarangDetail`, `qtyDetail`, `hargaDetail`, `deskripsiDetail`, `barangDetailKosong`, `kodeDetailOrderKosong`, `gambarDetailKosong`) VALUES (44, '120020', 12, 0, 8, 86876, '8687', '8768', '8768', '0241992b2917d969d40e4b068d962bbc.jpg');
INSERT INTO `detailorders` (`idDetailOrders`, `noTransaksiDetail`, `idKaryawanDetail`, `idBarangDetail`, `qtyDetail`, `hargaDetail`, `deskripsiDetail`, `barangDetailKosong`, `kodeDetailOrderKosong`, `gambarDetailKosong`) VALUES (45, '120024', 12, 2, 2, 2000, '', '', '', '');
INSERT INTO `detailorders` (`idDetailOrders`, `noTransaksiDetail`, `idKaryawanDetail`, `idBarangDetail`, `qtyDetail`, `hargaDetail`, `deskripsiDetail`, `barangDetailKosong`, `kodeDetailOrderKosong`, `gambarDetailKosong`) VALUES (46, '120024', 12, 4, 2, 2000, '', '', '', '');
INSERT INTO `detailorders` (`idDetailOrders`, `noTransaksiDetail`, `idKaryawanDetail`, `idBarangDetail`, `qtyDetail`, `hargaDetail`, `deskripsiDetail`, `barangDetailKosong`, `kodeDetailOrderKosong`, `gambarDetailKosong`) VALUES (47, '120025', 12, 4, 8, 2000, '', '', '', '');
INSERT INTO `detailorders` (`idDetailOrders`, `noTransaksiDetail`, `idKaryawanDetail`, `idBarangDetail`, `qtyDetail`, `hargaDetail`, `deskripsiDetail`, `barangDetailKosong`, `kodeDetailOrderKosong`, `gambarDetailKosong`) VALUES (48, '120025', 12, 5, 8, 2000, '', '', '', '');
INSERT INTO `detailorders` (`idDetailOrders`, `noTransaksiDetail`, `idKaryawanDetail`, `idBarangDetail`, `qtyDetail`, `hargaDetail`, `deskripsiDetail`, `barangDetailKosong`, `kodeDetailOrderKosong`, `gambarDetailKosong`) VALUES (49, '120029', 12, 0, 2, 1000, 'Deskribsi coba', 'barang coba', '1', '8352e6ddd965f6b1d689dd3cc48c1a06.jpg');
INSERT INTO `detailorders` (`idDetailOrders`, `noTransaksiDetail`, `idKaryawanDetail`, `idBarangDetail`, `qtyDetail`, `hargaDetail`, `deskripsiDetail`, `barangDetailKosong`, `kodeDetailOrderKosong`, `gambarDetailKosong`) VALUES (50, '120029', 12, 0, 10, 10000, 'Deskribsi coba 2', 'barang coba 2', '2', '925ce8381e3e018c80befd18b94c4e2c.jpg');
INSERT INTO `detailorders` (`idDetailOrders`, `noTransaksiDetail`, `idKaryawanDetail`, `idBarangDetail`, `qtyDetail`, `hargaDetail`, `deskripsiDetail`, `barangDetailKosong`, `kodeDetailOrderKosong`, `gambarDetailKosong`) VALUES (51, '120029', 12, 0, 10, 10000, 'Deskribsi coba 3', 'barang coba 3', '3', '986b5589fd20d6dfd1eb9d37023081f1.png');
INSERT INTO `detailorders` (`idDetailOrders`, `noTransaksiDetail`, `idKaryawanDetail`, `idBarangDetail`, `qtyDetail`, `hargaDetail`, `deskripsiDetail`, `barangDetailKosong`, `kodeDetailOrderKosong`, `gambarDetailKosong`) VALUES (52, '120029', 12, 0, 200, 10000, 'Deskribsi coba 4', 'barang coba 4', '4', '0c705d795fac93e380a42f5198d83f2e.png');
INSERT INTO `detailorders` (`idDetailOrders`, `noTransaksiDetail`, `idKaryawanDetail`, `idBarangDetail`, `qtyDetail`, `hargaDetail`, `deskripsiDetail`, `barangDetailKosong`, `kodeDetailOrderKosong`, `gambarDetailKosong`) VALUES (53, '120029', 12, 0, 1000, 20000, 'Deskribsi coba 5', 'barang coba 5', '5', '27b01ba8f34d27c46a5d918752168589.jpg');
INSERT INTO `detailorders` (`idDetailOrders`, `noTransaksiDetail`, `idKaryawanDetail`, `idBarangDetail`, `qtyDetail`, `hargaDetail`, `deskripsiDetail`, `barangDetailKosong`, `kodeDetailOrderKosong`, `gambarDetailKosong`) VALUES (54, '120029', 12, 0, 100, 10000, 'Deskribsi coba 6', 'barang coba 6', '6', '8ee15e55e0b63294ba0f09e4b68098c7.jpg');
INSERT INTO `detailorders` (`idDetailOrders`, `noTransaksiDetail`, `idKaryawanDetail`, `idBarangDetail`, `qtyDetail`, `hargaDetail`, `deskripsiDetail`, `barangDetailKosong`, `kodeDetailOrderKosong`, `gambarDetailKosong`) VALUES (55, '120029', 12, 0, 3, 10000, 'Box 23 tek wim', 'Cicin Permata', '7', '76ac6100ace0e6c14d756a3e975f0ec9.jpg');
INSERT INTO `detailorders` (`idDetailOrders`, `noTransaksiDetail`, `idKaryawanDetail`, `idBarangDetail`, `qtyDetail`, `hargaDetail`, `deskripsiDetail`, `barangDetailKosong`, `kodeDetailOrderKosong`, `gambarDetailKosong`) VALUES (56, '120029', 12, 0, 100, 10000, 'Deskribsi coba 8', 'barang coba 8', '8', 'e940b6b95fda5a10f8074f54d2184d6c.jpg');
INSERT INTO `detailorders` (`idDetailOrders`, `noTransaksiDetail`, `idKaryawanDetail`, `idBarangDetail`, `qtyDetail`, `hargaDetail`, `deskripsiDetail`, `barangDetailKosong`, `kodeDetailOrderKosong`, `gambarDetailKosong`) VALUES (57, '120029', 12, 0, 19, 100000, 'Deskribsi coba 10', 'barang coba 10', '9', 'd51934173ab075c9a038de697c061254.jpg');
INSERT INTO `detailorders` (`idDetailOrders`, `noTransaksiDetail`, `idKaryawanDetail`, `idBarangDetail`, `qtyDetail`, `hargaDetail`, `deskripsiDetail`, `barangDetailKosong`, `kodeDetailOrderKosong`, `gambarDetailKosong`) VALUES (58, '120029', 12, 0, 100, 10000, 'Deskribsi coba 10', 'barang coba 10', '10', 'a33963b91e1661b1c68d5b7637a90790.jpg');


#
# TABLE STRUCTURE FOR: karyawan
#

DROP TABLE IF EXISTS `karyawan`;

CREATE TABLE `karyawan` (
  `idKaryawan` int(11) NOT NULL AUTO_INCREMENT,
  `namaKaryawan` varchar(200) NOT NULL,
  `alamatKaryawan` text NOT NULL,
  `noTlpKaryawan` char(12) NOT NULL,
  `usernameKaryawan` varchar(100) NOT NULL,
  `passwordKaryawan` varchar(200) NOT NULL,
  `fotoKaryawan` varchar(150) NOT NULL,
  `statusKaryawan` enum('umum','super') NOT NULL,
  PRIMARY KEY (`idKaryawan`)
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=utf8mb4;

INSERT INTO `karyawan` (`idKaryawan`, `namaKaryawan`, `alamatKaryawan`, `noTlpKaryawan`, `usernameKaryawan`, `passwordKaryawan`, `fotoKaryawan`, `statusKaryawan`) VALUES (10, 'Fafa Anggaa', 'SBY', '086554365787', 'fafa', '05d251ea28c5be9426611a121db0c92a', '89a297cbf6a271a1be2e1c1d4d63e972.jpg', 'umum');
INSERT INTO `karyawan` (`idKaryawan`, `namaKaryawan`, `alamatKaryawan`, `noTlpKaryawan`, `usernameKaryawan`, `passwordKaryawan`, `fotoKaryawan`, `statusKaryawan`) VALUES (11, 'Nadifah A\'yun', 'Pajarakan', '081333355566', 'ayun', '202cb962ac59075b964b07152d234b70', '', 'umum');
INSERT INTO `karyawan` (`idKaryawan`, `namaKaryawan`, `alamatKaryawan`, `noTlpKaryawan`, `usernameKaryawan`, `passwordKaryawan`, `fotoKaryawan`, `statusKaryawan`) VALUES (12, 'El Hariyanto', 'Bali    ', '081111111232', 'hari', '21232f297a57a5a743894a0e4a801fc3', '', 'super');
INSERT INTO `karyawan` (`idKaryawan`, `namaKaryawan`, `alamatKaryawan`, `noTlpKaryawan`, `usernameKaryawan`, `passwordKaryawan`, `fotoKaryawan`, `statusKaryawan`) VALUES (14, '98798', '9798', '7979', '7987', '52f9318e8dd9614c45e33b557bf4fb87', '', 'umum');


#
# TABLE STRUCTURE FOR: pengiriman
#

DROP TABLE IF EXISTS `pengiriman`;

CREATE TABLE `pengiriman` (
  `idPengiriman` int(11) NOT NULL AUTO_INCREMENT,
  `noBox` varchar(50) NOT NULL,
  `idDetailOrdersBox` int(11) NOT NULL,
  `noTransaksiBox` varchar(50) NOT NULL,
  `idBarangBox` int(11) NOT NULL,
  `qtyBox` int(11) NOT NULL,
  `tanggalBox` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`idPengiriman`)
) ENGINE=InnoDB AUTO_INCREMENT=20 DEFAULT CHARSET=utf8mb4;

INSERT INTO `pengiriman` (`idPengiriman`, `noBox`, `idDetailOrdersBox`, `noTransaksiBox`, `idBarangBox`, `qtyBox`, `tanggalBox`) VALUES (1, '1', 2, '110001', 6, 2000, '2020-06-05 00:17:43');
INSERT INTO `pengiriman` (`idPengiriman`, `noBox`, `idDetailOrdersBox`, `noTransaksiBox`, `idBarangBox`, `qtyBox`, `tanggalBox`) VALUES (2, '2', 1, '110001', 3, 100, '2020-06-05 00:17:51');
INSERT INTO `pengiriman` (`idPengiriman`, `noBox`, `idDetailOrdersBox`, `noTransaksiBox`, `idBarangBox`, `qtyBox`, `tanggalBox`) VALUES (3, '1', 4, '120002', 3, 100, '2020-06-12 06:04:00');
INSERT INTO `pengiriman` (`idPengiriman`, `noBox`, `idDetailOrdersBox`, `noTransaksiBox`, `idBarangBox`, `qtyBox`, `tanggalBox`) VALUES (4, '2', 3, '120002', 2, 5, '2020-06-12 06:04:13');
INSERT INTO `pengiriman` (`idPengiriman`, `noBox`, `idDetailOrdersBox`, `noTransaksiBox`, `idBarangBox`, `qtyBox`, `tanggalBox`) VALUES (14, '1', 11, '111111', 0, 3, '2020-06-12 08:03:59');
INSERT INTO `pengiriman` (`idPengiriman`, `noBox`, `idDetailOrdersBox`, `noTransaksiBox`, `idBarangBox`, `qtyBox`, `tanggalBox`) VALUES (15, '2', 10, '111111', 0, 2, '2020-06-12 08:04:09');
INSERT INTO `pengiriman` (`idPengiriman`, `noBox`, `idDetailOrdersBox`, `noTransaksiBox`, `idBarangBox`, `qtyBox`, `tanggalBox`) VALUES (16, '1', 13, '10000', 0, 2, '2020-06-12 17:35:00');
INSERT INTO `pengiriman` (`idPengiriman`, `noBox`, `idDetailOrdersBox`, `noTransaksiBox`, `idBarangBox`, `qtyBox`, `tanggalBox`) VALUES (18, '1', 57, '120035', 0, 499, '2020-06-17 06:33:02');
INSERT INTO `pengiriman` (`idPengiriman`, `noBox`, `idDetailOrdersBox`, `noTransaksiBox`, `idBarangBox`, `qtyBox`, `tanggalBox`) VALUES (19, '2', 57, '120035', 0, 500, '2020-06-17 06:33:10');


#
# TABLE STRUCTURE FOR: suplayer
#

DROP TABLE IF EXISTS `suplayer`;

CREATE TABLE `suplayer` (
  `idSuplayer` int(11) NOT NULL AUTO_INCREMENT,
  `namaSuplayer` varchar(200) NOT NULL,
  `alamatSuplayer` text NOT NULL,
  `noTlpSuplayer` char(12) NOT NULL,
  `statusSuplayer` enum('ongkosan','ordersan') NOT NULL,
  PRIMARY KEY (`idSuplayer`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4;

INSERT INTO `suplayer` (`idSuplayer`, `namaSuplayer`, `alamatSuplayer`, `noTlpSuplayer`, `statusSuplayer`) VALUES (2, 'Tri Yuni Puspita', 'Surabaya Malang', '082332165817', 'ongkosan');
INSERT INTO `suplayer` (`idSuplayer`, `namaSuplayer`, `alamatSuplayer`, `noTlpSuplayer`, `statusSuplayer`) VALUES (3, 'Nadifah Qurrotu A\'yun', 'Malang', '087666555443', 'ordersan');
INSERT INTO `suplayer` (`idSuplayer`, `namaSuplayer`, `alamatSuplayer`, `noTlpSuplayer`, `statusSuplayer`) VALUES (6, 'Hadi Ningrat', 'Besuki', '087222444888', 'ongkosan');
INSERT INTO `suplayer` (`idSuplayer`, `namaSuplayer`, `alamatSuplayer`, `noTlpSuplayer`, `statusSuplayer`) VALUES (7, 'Suooo', '09809', '0809', 'ongkosan');
INSERT INTO `suplayer` (`idSuplayer`, `namaSuplayer`, `alamatSuplayer`, `noTlpSuplayer`, `statusSuplayer`) VALUES (9, 'Coba', 'Kooko', '99876', 'ongkosan');
INSERT INTO `suplayer` (`idSuplayer`, `namaSuplayer`, `alamatSuplayer`, `noTlpSuplayer`, `statusSuplayer`) VALUES (10, 'Coba 1', 'Pppp', '0987', 'ongkosan');


#
# TABLE STRUCTURE FOR: temporders
#

DROP TABLE IF EXISTS `temporders`;

CREATE TABLE `temporders` (
  `idTempOrders` int(11) NOT NULL AUTO_INCREMENT,
  `idKaryawanTemp` int(11) NOT NULL,
  `idBarangTemp` int(11) NOT NULL,
  `hargaTemp` int(11) NOT NULL,
  `qtyTemp` int(11) NOT NULL,
  PRIMARY KEY (`idTempOrders`)
) ENGINE=InnoDB AUTO_INCREMENT=128 DEFAULT CHARSET=utf8mb4;

INSERT INTO `temporders` (`idTempOrders`, `idKaryawanTemp`, `idBarangTemp`, `hargaTemp`, `qtyTemp`) VALUES (120, 10, 1, 2000, 4);


#
# TABLE STRUCTURE FOR: temporderskosong
#

DROP TABLE IF EXISTS `temporderskosong`;

CREATE TABLE `temporderskosong` (
  `idTempOrdersKosong` int(11) NOT NULL AUTO_INCREMENT,
  `kodeOrderKosong` varchar(50) NOT NULL,
  `idKaryawanTempKosong` int(11) NOT NULL,
  `namaBarangTempKosong` varchar(200) NOT NULL,
  `hargaTempKosong` int(11) NOT NULL,
  `qtyTempKosong` int(11) NOT NULL,
  `deskripsiTempKosong` text NOT NULL,
  `gambarTempKosong` varchar(200) NOT NULL,
  PRIMARY KEY (`idTempOrdersKosong`)
) ENGINE=InnoDB AUTO_INCREMENT=149 DEFAULT CHARSET=utf8mb4;

INSERT INTO `temporderskosong` (`idTempOrdersKosong`, `kodeOrderKosong`, `idKaryawanTempKosong`, `namaBarangTempKosong`, `hargaTempKosong`, `qtyTempKosong`, `deskripsiTempKosong`, `gambarTempKosong`) VALUES (148, '123', 12, 'Cicin Permata', 200000, 3, 'Deskribsi coba', 'b2535a59483081832fab48030edea0eb.png');


#
# TABLE STRUCTURE FOR: temporderspesan
#

DROP TABLE IF EXISTS `temporderspesan`;

CREATE TABLE `temporderspesan` (
  `idTempOrdersPesan` int(11) NOT NULL AUTO_INCREMENT,
  `idKaryawanTempPesan` int(11) NOT NULL,
  `idBarangTempPesan` int(11) NOT NULL,
  `hargaTempPesan` int(50) NOT NULL,
  `qtyTempPesan` int(11) NOT NULL,
  `deskripsiTempPesan` text NOT NULL,
  PRIMARY KEY (`idTempOrdersPesan`)
) ENGINE=InnoDB AUTO_INCREMENT=117 DEFAULT CHARSET=utf8mb4;

INSERT INTO `temporderspesan` (`idTempOrdersPesan`, `idKaryawanTempPesan`, `idBarangTempPesan`, `hargaTempPesan`, `qtyTempPesan`, `deskripsiTempPesan`) VALUES (36, 1, 5, 11111, 2, 'Cekkk');


#
# TABLE STRUCTURE FOR: transaksi
#

DROP TABLE IF EXISTS `transaksi`;

CREATE TABLE `transaksi` (
  `idTransaksi` int(11) NOT NULL AUTO_INCREMENT,
  `idKaryawanTransaksi` int(11) NOT NULL,
  `noTransaksi` varchar(150) NOT NULL,
  `tanggalInvoice` date NOT NULL,
  `idPelanggan` int(11) NOT NULL,
  `totalTransaksi` int(11) NOT NULL,
  `metodeBayar` enum('Debit','Tunai') NOT NULL,
  `bayarTransaksi` int(11) NOT NULL,
  `kembalianTransaksi` int(11) NOT NULL,
  `dpTransaksi` int(11) NOT NULL,
  `sisaBayar` float NOT NULL,
  `tanggalLunas` date NOT NULL,
  `statusTransaksi` enum('bayar','pesan','kosong','suplayer') NOT NULL,
  `tindakan` enum('baru','proses','selesai') NOT NULL,
  `tanggalTransaksi` timestamp NOT NULL DEFAULT current_timestamp(),
  `tanggal_invoice` timestamp NOT NULL DEFAULT current_timestamp(),
  `link` varchar(250) NOT NULL,
  `statusBox` varchar(10) NOT NULL,
  `pengeluaran` enum('belum','lunas') NOT NULL,
  `persenNotaPalsu` int(3) NOT NULL,
  PRIMARY KEY (`idTransaksi`)
) ENGINE=InnoDB AUTO_INCREMENT=37 DEFAULT CHARSET=utf8mb4;

INSERT INTO `transaksi` (`idTransaksi`, `idKaryawanTransaksi`, `noTransaksi`, `tanggalInvoice`, `idPelanggan`, `totalTransaksi`, `metodeBayar`, `bayarTransaksi`, `kembalianTransaksi`, `dpTransaksi`, `sisaBayar`, `tanggalLunas`, `statusTransaksi`, `tindakan`, `tanggalTransaksi`, `tanggal_invoice`, `link`, `statusBox`, `pengeluaran`, `persenNotaPalsu`) VALUES (3, 12, '120001', '2020-06-22', 10, 220000, 'Tunai', 0, 0, 0, '-220000', '2020-06-23', 'pesan', 'selesai', '2020-06-21 19:35:18', '2020-06-21 19:35:18', 'pesan1592793318', '', 'lunas', 0);
INSERT INTO `transaksi` (`idTransaksi`, `idKaryawanTransaksi`, `noTransaksi`, `tanggalInvoice`, `idPelanggan`, `totalTransaksi`, `metodeBayar`, `bayarTransaksi`, `kembalianTransaksi`, `dpTransaksi`, `sisaBayar`, `tanggalLunas`, `statusTransaksi`, `tindakan`, `tanggalTransaksi`, `tanggal_invoice`, `link`, `statusBox`, `pengeluaran`, `persenNotaPalsu`) VALUES (4, 12, '120002', '2020-06-22', 2, 190000, 'Tunai', 0, 0, 1000, '-189000', '2020-06-23', 'kosong', 'selesai', '2020-06-21 19:36:24', '2020-06-21 19:36:24', 'kosong1592793384', '', 'lunas', 0);
INSERT INTO `transaksi` (`idTransaksi`, `idKaryawanTransaksi`, `noTransaksi`, `tanggalInvoice`, `idPelanggan`, `totalTransaksi`, `metodeBayar`, `bayarTransaksi`, `kembalianTransaksi`, `dpTransaksi`, `sisaBayar`, `tanggalLunas`, `statusTransaksi`, `tindakan`, `tanggalTransaksi`, `tanggal_invoice`, `link`, `statusBox`, `pengeluaran`, `persenNotaPalsu`) VALUES (5, 12, '120003', '2020-06-25', 10, 600000, 'Debit', 0, 0, 0, '-600000', '0000-00-00', 'pesan', 'selesai', '2020-06-25 06:09:18', '2020-06-25 06:09:18', 'pesan1593090558', '', 'lunas', 0);
INSERT INTO `transaksi` (`idTransaksi`, `idKaryawanTransaksi`, `noTransaksi`, `tanggalInvoice`, `idPelanggan`, `totalTransaksi`, `metodeBayar`, `bayarTransaksi`, `kembalianTransaksi`, `dpTransaksi`, `sisaBayar`, `tanggalLunas`, `statusTransaksi`, `tindakan`, `tanggalTransaksi`, `tanggal_invoice`, `link`, `statusBox`, `pengeluaran`, `persenNotaPalsu`) VALUES (6, 12, '120004', '2020-07-06', 11, 2147483647, 'Debit', 0, 0, 0, '-86556000000', '0000-00-00', 'kosong', 'proses', '2020-07-06 05:29:45', '2020-07-06 05:29:45', 'kosong1594038585', '', 'belum', 0);
INSERT INTO `transaksi` (`idTransaksi`, `idKaryawanTransaksi`, `noTransaksi`, `tanggalInvoice`, `idPelanggan`, `totalTransaksi`, `metodeBayar`, `bayarTransaksi`, `kembalianTransaksi`, `dpTransaksi`, `sisaBayar`, `tanggalLunas`, `statusTransaksi`, `tindakan`, `tanggalTransaksi`, `tanggal_invoice`, `link`, `statusBox`, `pengeluaran`, `persenNotaPalsu`) VALUES (7, 12, '120005', '2020-07-06', 11, 86139273, 'Debit', 0, 0, 0, '-86139300', '0000-00-00', 'kosong', 'proses', '2020-07-06 05:34:32', '2020-07-06 05:34:32', 'kosong1594038872', '', 'belum', 0);
INSERT INTO `transaksi` (`idTransaksi`, `idKaryawanTransaksi`, `noTransaksi`, `tanggalInvoice`, `idPelanggan`, `totalTransaksi`, `metodeBayar`, `bayarTransaksi`, `kembalianTransaksi`, `dpTransaksi`, `sisaBayar`, `tanggalLunas`, `statusTransaksi`, `tindakan`, `tanggalTransaksi`, `tanggal_invoice`, `link`, `statusBox`, `pengeluaran`, `persenNotaPalsu`) VALUES (8, 12, '120006', '2020-07-06', 11, 2147483647, 'Debit', 0, 0, 0, '-9346560000', '0000-00-00', 'kosong', 'proses', '2020-07-06 05:39:35', '2020-07-06 05:39:35', 'kosong1594039175', '', 'belum', 0);
INSERT INTO `transaksi` (`idTransaksi`, `idKaryawanTransaksi`, `noTransaksi`, `tanggalInvoice`, `idPelanggan`, `totalTransaksi`, `metodeBayar`, `bayarTransaksi`, `kembalianTransaksi`, `dpTransaksi`, `sisaBayar`, `tanggalLunas`, `statusTransaksi`, `tindakan`, `tanggalTransaksi`, `tanggal_invoice`, `link`, `statusBox`, `pengeluaran`, `persenNotaPalsu`) VALUES (9, 12, '120007', '2020-07-06', 9, 876952799, 'Tunai', 0, 0, 0, '-876953000', '0000-00-00', 'kosong', 'proses', '2020-07-06 05:44:29', '2020-07-06 05:44:29', 'kosong1594039469', '', 'belum', 0);
INSERT INTO `transaksi` (`idTransaksi`, `idKaryawanTransaksi`, `noTransaksi`, `tanggalInvoice`, `idPelanggan`, `totalTransaksi`, `metodeBayar`, `bayarTransaksi`, `kembalianTransaksi`, `dpTransaksi`, `sisaBayar`, `tanggalLunas`, `statusTransaksi`, `tindakan`, `tanggalTransaksi`, `tanggal_invoice`, `link`, `statusBox`, `pengeluaran`, `persenNotaPalsu`) VALUES (10, 12, '120008', '2020-07-06', 6, 1551929, 'Debit', 0, 0, 0, '-1551930', '0000-00-00', 'kosong', 'proses', '2020-07-06 05:50:00', '2020-07-06 05:50:00', 'kosong1594039800', '', 'belum', 0);
INSERT INTO `transaksi` (`idTransaksi`, `idKaryawanTransaksi`, `noTransaksi`, `tanggalInvoice`, `idPelanggan`, `totalTransaksi`, `metodeBayar`, `bayarTransaksi`, `kembalianTransaksi`, `dpTransaksi`, `sisaBayar`, `tanggalLunas`, `statusTransaksi`, `tindakan`, `tanggalTransaksi`, `tanggal_invoice`, `link`, `statusBox`, `pengeluaran`, `persenNotaPalsu`) VALUES (11, 12, '120009', '2020-07-06', 10, 89991, 'Tunai', 0, 0, 0, '-89991', '0000-00-00', 'kosong', 'proses', '2020-07-06 05:55:01', '2020-07-06 05:55:01', 'kosong1594040101', '', 'belum', 0);
INSERT INTO `transaksi` (`idTransaksi`, `idKaryawanTransaksi`, `noTransaksi`, `tanggalInvoice`, `idPelanggan`, `totalTransaksi`, `metodeBayar`, `bayarTransaksi`, `kembalianTransaksi`, `dpTransaksi`, `sisaBayar`, `tanggalLunas`, `statusTransaksi`, `tindakan`, `tanggalTransaksi`, `tanggal_invoice`, `link`, `statusBox`, `pengeluaran`, `persenNotaPalsu`) VALUES (12, 12, '120010', '2020-07-06', 11, 75639551, 'Debit', 0, 0, 0, '-75639600', '0000-00-00', 'kosong', 'proses', '2020-07-06 06:03:11', '2020-07-06 06:03:11', 'kosong1594040591', '', 'belum', 0);
INSERT INTO `transaksi` (`idTransaksi`, `idKaryawanTransaksi`, `noTransaksi`, `tanggalInvoice`, `idPelanggan`, `totalTransaksi`, `metodeBayar`, `bayarTransaksi`, `kembalianTransaksi`, `dpTransaksi`, `sisaBayar`, `tanggalLunas`, `statusTransaksi`, `tindakan`, `tanggalTransaksi`, `tanggal_invoice`, `link`, `statusBox`, `pengeluaran`, `persenNotaPalsu`) VALUES (13, 12, '120011', '2020-07-06', 12, 62216, 'Tunai', 0, 0, 0, '-62216', '0000-00-00', 'kosong', 'proses', '2020-07-06 06:36:33', '2020-07-06 06:36:33', 'kosong1594042593', '', 'belum', 0);
INSERT INTO `transaksi` (`idTransaksi`, `idKaryawanTransaksi`, `noTransaksi`, `tanggalInvoice`, `idPelanggan`, `totalTransaksi`, `metodeBayar`, `bayarTransaksi`, `kembalianTransaksi`, `dpTransaksi`, `sisaBayar`, `tanggalLunas`, `statusTransaksi`, `tindakan`, `tanggalTransaksi`, `tanggal_invoice`, `link`, `statusBox`, `pengeluaran`, `persenNotaPalsu`) VALUES (14, 12, '120012', '2020-07-06', 12, 753424, 'Debit', 0, 0, 0, '-753424', '0000-00-00', 'kosong', 'proses', '2020-07-06 06:39:53', '2020-07-06 06:39:53', 'kosong1594042793', '', 'belum', 0);
INSERT INTO `transaksi` (`idTransaksi`, `idKaryawanTransaksi`, `noTransaksi`, `tanggalInvoice`, `idPelanggan`, `totalTransaksi`, `metodeBayar`, `bayarTransaksi`, `kembalianTransaksi`, `dpTransaksi`, `sisaBayar`, `tanggalLunas`, `statusTransaksi`, `tindakan`, `tanggalTransaksi`, `tanggal_invoice`, `link`, `statusBox`, `pengeluaran`, `persenNotaPalsu`) VALUES (15, 12, '120013', '2020-07-06', 12, 753424, 'Debit', 0, 0, 0, '-753424', '0000-00-00', 'kosong', 'proses', '2020-07-06 06:44:14', '2020-07-06 06:44:14', 'kosong1594043054', '', 'belum', 0);
INSERT INTO `transaksi` (`idTransaksi`, `idKaryawanTransaksi`, `noTransaksi`, `tanggalInvoice`, `idPelanggan`, `totalTransaksi`, `metodeBayar`, `bayarTransaksi`, `kembalianTransaksi`, `dpTransaksi`, `sisaBayar`, `tanggalLunas`, `statusTransaksi`, `tindakan`, `tanggalTransaksi`, `tanggal_invoice`, `link`, `statusBox`, `pengeluaran`, `persenNotaPalsu`) VALUES (16, 12, '120014', '2020-07-06', 12, 753424, 'Tunai', 0, 0, 0, '-753424', '0000-00-00', 'kosong', 'proses', '2020-07-06 06:47:08', '2020-07-06 06:47:08', 'kosong1594043228', '', 'belum', 0);
INSERT INTO `transaksi` (`idTransaksi`, `idKaryawanTransaksi`, `noTransaksi`, `tanggalInvoice`, `idPelanggan`, `totalTransaksi`, `metodeBayar`, `bayarTransaksi`, `kembalianTransaksi`, `dpTransaksi`, `sisaBayar`, `tanggalLunas`, `statusTransaksi`, `tindakan`, `tanggalTransaksi`, `tanggal_invoice`, `link`, `statusBox`, `pengeluaran`, `persenNotaPalsu`) VALUES (17, 12, '120015', '2020-07-06', 11, 873000, 'Debit', 0, 0, 0, '-873000', '0000-00-00', 'kosong', 'proses', '2020-07-06 06:48:04', '2020-07-06 06:48:04', 'kosong1594043284', '', 'belum', 0);
INSERT INTO `transaksi` (`idTransaksi`, `idKaryawanTransaksi`, `noTransaksi`, `tanggalInvoice`, `idPelanggan`, `totalTransaksi`, `metodeBayar`, `bayarTransaksi`, `kembalianTransaksi`, `dpTransaksi`, `sisaBayar`, `tanggalLunas`, `statusTransaksi`, `tindakan`, `tanggalTransaksi`, `tanggal_invoice`, `link`, `statusBox`, `pengeluaran`, `persenNotaPalsu`) VALUES (18, 12, '120015', '2020-07-06', 11, 873000, 'Debit', 0, 0, 0, '-873000', '0000-00-00', 'kosong', 'proses', '2020-07-06 06:48:55', '2020-07-06 06:48:55', 'kosong1594043335', '', 'belum', 0);
INSERT INTO `transaksi` (`idTransaksi`, `idKaryawanTransaksi`, `noTransaksi`, `tanggalInvoice`, `idPelanggan`, `totalTransaksi`, `metodeBayar`, `bayarTransaksi`, `kembalianTransaksi`, `dpTransaksi`, `sisaBayar`, `tanggalLunas`, `statusTransaksi`, `tindakan`, `tanggalTransaksi`, `tanggal_invoice`, `link`, `statusBox`, `pengeluaran`, `persenNotaPalsu`) VALUES (19, 12, '120016', '2020-07-06', 10, 754369, 'Tunai', 0, 0, 0, '-754369', '0000-00-00', 'kosong', 'proses', '2020-07-06 06:50:01', '2020-07-06 06:50:01', 'kosong1594043401', '', 'belum', 0);
INSERT INTO `transaksi` (`idTransaksi`, `idKaryawanTransaksi`, `noTransaksi`, `tanggalInvoice`, `idPelanggan`, `totalTransaksi`, `metodeBayar`, `bayarTransaksi`, `kembalianTransaksi`, `dpTransaksi`, `sisaBayar`, `tanggalLunas`, `statusTransaksi`, `tindakan`, `tanggalTransaksi`, `tanggal_invoice`, `link`, `statusBox`, `pengeluaran`, `persenNotaPalsu`) VALUES (20, 12, '120017', '2020-07-06', 6, 45288, 'Tunai', 0, 0, 0, '-45288', '0000-00-00', 'kosong', 'proses', '2020-07-06 06:52:38', '2020-07-06 06:52:38', 'kosong1594043558', '', 'belum', 0);
INSERT INTO `transaksi` (`idTransaksi`, `idKaryawanTransaksi`, `noTransaksi`, `tanggalInvoice`, `idPelanggan`, `totalTransaksi`, `metodeBayar`, `bayarTransaksi`, `kembalianTransaksi`, `dpTransaksi`, `sisaBayar`, `tanggalLunas`, `statusTransaksi`, `tindakan`, `tanggalTransaksi`, `tanggal_invoice`, `link`, `statusBox`, `pengeluaran`, `persenNotaPalsu`) VALUES (21, 12, '120018', '2020-07-07', 11, 12000, 'Debit', 0, 0, 0, '-12000', '0000-00-00', 'kosong', 'proses', '2020-07-06 16:05:09', '2020-07-06 16:05:09', 'kosong1594076709', '', 'belum', 0);
INSERT INTO `transaksi` (`idTransaksi`, `idKaryawanTransaksi`, `noTransaksi`, `tanggalInvoice`, `idPelanggan`, `totalTransaksi`, `metodeBayar`, `bayarTransaksi`, `kembalianTransaksi`, `dpTransaksi`, `sisaBayar`, `tanggalLunas`, `statusTransaksi`, `tindakan`, `tanggalTransaksi`, `tanggal_invoice`, `link`, `statusBox`, `pengeluaran`, `persenNotaPalsu`) VALUES (22, 12, '120019', '2020-07-07', 12, 695014, 'Debit', 0, 0, 0, '-695014', '0000-00-00', 'kosong', 'proses', '2020-07-06 16:45:34', '2020-07-06 16:45:34', 'kosong1594079134', '', 'belum', 0);
INSERT INTO `transaksi` (`idTransaksi`, `idKaryawanTransaksi`, `noTransaksi`, `tanggalInvoice`, `idPelanggan`, `totalTransaksi`, `metodeBayar`, `bayarTransaksi`, `kembalianTransaksi`, `dpTransaksi`, `sisaBayar`, `tanggalLunas`, `statusTransaksi`, `tindakan`, `tanggalTransaksi`, `tanggal_invoice`, `link`, `statusBox`, `pengeluaran`, `persenNotaPalsu`) VALUES (23, 12, '120020', '2021-04-05', 5, 695014, 'Debit', 0, 0, 700000, '4986', '2021-04-05', 'kosong', 'proses', '2021-04-05 05:03:31', '2021-04-05 05:03:31', 'kosong1617624211', '', 'belum', 90);
INSERT INTO `transaksi` (`idTransaksi`, `idKaryawanTransaksi`, `noTransaksi`, `tanggalInvoice`, `idPelanggan`, `totalTransaksi`, `metodeBayar`, `bayarTransaksi`, `kembalianTransaksi`, `dpTransaksi`, `sisaBayar`, `tanggalLunas`, `statusTransaksi`, `tindakan`, `tanggalTransaksi`, `tanggal_invoice`, `link`, `statusBox`, `pengeluaran`, `persenNotaPalsu`) VALUES (29, 12, '120022', '2021-04-09', 9, 972000, 'Debit', 0, 0, 100000, '-872000', '2021-04-08', 'suplayer', 'proses', '2021-04-08 18:04:32', '2021-04-08 18:04:32', 'suplayer1617930272', '', 'belum', 10);
INSERT INTO `transaksi` (`idTransaksi`, `idKaryawanTransaksi`, `noTransaksi`, `tanggalInvoice`, `idPelanggan`, `totalTransaksi`, `metodeBayar`, `bayarTransaksi`, `kembalianTransaksi`, `dpTransaksi`, `sisaBayar`, `tanggalLunas`, `statusTransaksi`, `tindakan`, `tanggalTransaksi`, `tanggal_invoice`, `link`, `statusBox`, `pengeluaran`, `persenNotaPalsu`) VALUES (30, 12, '120023', '2021-04-09', 3, 954000, 'Tunai', 0, 0, 0, '-954000', '2021-04-08', 'suplayer', 'proses', '2021-04-08 20:22:12', '2021-04-08 20:22:12', 'suplayer1617938532', '', 'belum', 0);
INSERT INTO `transaksi` (`idTransaksi`, `idKaryawanTransaksi`, `noTransaksi`, `tanggalInvoice`, `idPelanggan`, `totalTransaksi`, `metodeBayar`, `bayarTransaksi`, `kembalianTransaksi`, `dpTransaksi`, `sisaBayar`, `tanggalLunas`, `statusTransaksi`, `tindakan`, `tanggalTransaksi`, `tanggal_invoice`, `link`, `statusBox`, `pengeluaran`, `persenNotaPalsu`) VALUES (31, 12, '120024', '2021-04-09', 3, 8000, 'Tunai', 9000, 1000, 0, '0', '0000-00-00', 'bayar', 'selesai', '2021-04-08 22:41:09', '2021-04-08 22:41:09', 'cash1617946869', '', 'belum', 0);
INSERT INTO `transaksi` (`idTransaksi`, `idKaryawanTransaksi`, `noTransaksi`, `tanggalInvoice`, `idPelanggan`, `totalTransaksi`, `metodeBayar`, `bayarTransaksi`, `kembalianTransaksi`, `dpTransaksi`, `sisaBayar`, `tanggalLunas`, `statusTransaksi`, `tindakan`, `tanggalTransaksi`, `tanggal_invoice`, `link`, `statusBox`, `pengeluaran`, `persenNotaPalsu`) VALUES (32, 12, '120025', '2021-04-09', 6, 32000, 'Tunai', 32000, 0, 0, '0', '0000-00-00', 'bayar', 'selesai', '2021-04-08 23:01:14', '2021-04-08 23:01:14', 'cash1617948074', '', 'belum', 0);
INSERT INTO `transaksi` (`idTransaksi`, `idKaryawanTransaksi`, `noTransaksi`, `tanggalInvoice`, `idPelanggan`, `totalTransaksi`, `metodeBayar`, `bayarTransaksi`, `kembalianTransaksi`, `dpTransaksi`, `sisaBayar`, `tanggalLunas`, `statusTransaksi`, `tindakan`, `tanggalTransaksi`, `tanggal_invoice`, `link`, `statusBox`, `pengeluaran`, `persenNotaPalsu`) VALUES (33, 12, '120026', '2021-04-09', 6, 80000, 'Tunai', 0, 0, 0, '-80000', '2021-04-08', 'suplayer', 'proses', '2021-04-08 23:13:46', '2021-04-08 23:13:46', 'suplayer1617948826', '', 'belum', 0);
INSERT INTO `transaksi` (`idTransaksi`, `idKaryawanTransaksi`, `noTransaksi`, `tanggalInvoice`, `idPelanggan`, `totalTransaksi`, `metodeBayar`, `bayarTransaksi`, `kembalianTransaksi`, `dpTransaksi`, `sisaBayar`, `tanggalLunas`, `statusTransaksi`, `tindakan`, `tanggalTransaksi`, `tanggal_invoice`, `link`, `statusBox`, `pengeluaran`, `persenNotaPalsu`) VALUES (34, 12, '120027', '2021-04-09', 3, 891000, 'Debit', 0, 0, 0, '-891000', '2021-04-10', 'suplayer', 'proses', '2021-04-09 00:23:47', '2021-04-09 00:23:47', 'suplayer1617953027', '', 'belum', 90);
INSERT INTO `transaksi` (`idTransaksi`, `idKaryawanTransaksi`, `noTransaksi`, `tanggalInvoice`, `idPelanggan`, `totalTransaksi`, `metodeBayar`, `bayarTransaksi`, `kembalianTransaksi`, `dpTransaksi`, `sisaBayar`, `tanggalLunas`, `statusTransaksi`, `tindakan`, `tanggalTransaksi`, `tanggal_invoice`, `link`, `statusBox`, `pengeluaran`, `persenNotaPalsu`) VALUES (35, 12, '120028', '2021-04-09', 2, 39000, 'Debit', 0, 0, 0, '-39000', '2021-04-09', 'suplayer', 'proses', '2021-04-09 00:46:50', '2021-04-09 00:46:50', 'suplayer1617954410', '', 'belum', 0);
INSERT INTO `transaksi` (`idTransaksi`, `idKaryawanTransaksi`, `noTransaksi`, `tanggalInvoice`, `idPelanggan`, `totalTransaksi`, `metodeBayar`, `bayarTransaksi`, `kembalianTransaksi`, `dpTransaksi`, `sisaBayar`, `tanggalLunas`, `statusTransaksi`, `tindakan`, `tanggalTransaksi`, `tanggal_invoice`, `link`, `statusBox`, `pengeluaran`, `persenNotaPalsu`) VALUES (36, 12, '120029', '2021-04-23', 10, 27132000, 'Tunai', 0, 0, 0, '-26132000', '2021-04-22', 'kosong', 'proses', '2021-04-22 14:08:28', '2021-04-22 14:08:28', 'kosong1619125708', '', 'belum', 0);


#
# TABLE STRUCTURE FOR: uangkeluar
#

DROP TABLE IF EXISTS `uangkeluar`;

CREATE TABLE `uangkeluar` (
  `idUangKeluar` int(11) NOT NULL AUTO_INCREMENT,
  `kodeUangKeluar` varchar(100) NOT NULL,
  `nominalUangKeluar` int(11) NOT NULL,
  `tanggalUangKeluar` date NOT NULL,
  `jamUangKeluar` char(50) NOT NULL,
  PRIMARY KEY (`idUangKeluar`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4;

INSERT INTO `uangkeluar` (`idUangKeluar`, `kodeUangKeluar`, `nominalUangKeluar`, `tanggalUangKeluar`, `jamUangKeluar`) VALUES (5, 'kode1592646287', 58000, '2020-06-20', '2:45 AM');
INSERT INTO `uangkeluar` (`idUangKeluar`, `kodeUangKeluar`, `nominalUangKeluar`, `tanggalUangKeluar`, `jamUangKeluar`) VALUES (6, 'kode1592646529', 490000, '2020-06-21', '2:45 AM');
INSERT INTO `uangkeluar` (`idUangKeluar`, `kodeUangKeluar`, `nominalUangKeluar`, `tanggalUangKeluar`, `jamUangKeluar`) VALUES (7, 'kode1592646721', 20000, '2020-06-20', '3:00 AM');


#
# TABLE STRUCTURE FOR: uangmasuk
#

DROP TABLE IF EXISTS `uangmasuk`;

CREATE TABLE `uangmasuk` (
  `idUangMasuk` int(11) NOT NULL AUTO_INCREMENT,
  `keteranganUangMasuk` text NOT NULL,
  `nominalUangMasuk` int(11) NOT NULL,
  `tanggalUangMasuk` date NOT NULL,
  `jamUangMasuk` char(50) NOT NULL,
  PRIMARY KEY (`idUangMasuk`)
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=utf8mb4;

INSERT INTO `uangmasuk` (`idUangMasuk`, `keteranganUangMasuk`, `nominalUangMasuk`, `tanggalUangMasuk`, `jamUangMasuk`) VALUES (10, 'Uang dari bos', 1000000, '2020-06-11', '7:00 PM');
INSERT INTO `uangmasuk` (`idUangMasuk`, `keteranganUangMasuk`, `nominalUangMasuk`, `tanggalUangMasuk`, `jamUangMasuk`) VALUES (12, 'Uang dari lembaga', 1000, '2020-07-10', '1:15 AM');
INSERT INTO `uangmasuk` (`idUangMasuk`, `keteranganUangMasuk`, `nominalUangMasuk`, `tanggalUangMasuk`, `jamUangMasuk`) VALUES (13, 'Coba', 10000, '2020-07-09', '1:15 AM');
INSERT INTO `uangmasuk` (`idUangMasuk`, `keteranganUangMasuk`, `nominalUangMasuk`, `tanggalUangMasuk`, `jamUangMasuk`) VALUES (14, 'Uang dari bos', 90000, '2020-07-09', '3:30 AM');


#
# TABLE STRUCTURE FOR: uangsuplayer
#

DROP TABLE IF EXISTS `uangsuplayer`;

CREATE TABLE `uangsuplayer` (
  `idUangSuplayer` int(11) NOT NULL AUTO_INCREMENT,
  `idDetailOrdersUangSuplayer` int(11) NOT NULL,
  `noTransaksiUangSuplayer` varchar(100) NOT NULL,
  `idSuplayerUangSuplayer` int(3) NOT NULL,
  `qtyUangSuplayer` int(5) NOT NULL,
  `hargaUangSuplayer` int(11) NOT NULL,
  `totalUangSuplayer` int(11) NOT NULL,
  `potonganUangSuplayer` int(11) NOT NULL,
  `keteranganUangSuplayer` text NOT NULL,
  PRIMARY KEY (`idUangSuplayer`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4;

INSERT INTO `uangsuplayer` (`idUangSuplayer`, `idDetailOrdersUangSuplayer`, `noTransaksiUangSuplayer`, `idSuplayerUangSuplayer`, `qtyUangSuplayer`, `hargaUangSuplayer`, `totalUangSuplayer`, `potonganUangSuplayer`, `keteranganUangSuplayer`) VALUES (1, 6, '120003', 6, 20, 2000, 40000, 2000, 'Oke');
INSERT INTO `uangsuplayer` (`idUangSuplayer`, `idDetailOrdersUangSuplayer`, `noTransaksiUangSuplayer`, `idSuplayerUangSuplayer`, `qtyUangSuplayer`, `hargaUangSuplayer`, `totalUangSuplayer`, `potonganUangSuplayer`, `keteranganUangSuplayer`) VALUES (2, 2, '120001', 6, 20, 1000, 20000, 9000, 'Potongan Awal tanggal 20 Juni 2020');
INSERT INTO `uangsuplayer` (`idUangSuplayer`, `idDetailOrdersUangSuplayer`, `noTransaksiUangSuplayer`, `idSuplayerUangSuplayer`, `qtyUangSuplayer`, `hargaUangSuplayer`, `totalUangSuplayer`, `potonganUangSuplayer`, `keteranganUangSuplayer`) VALUES (3, 2, '120001', 2, 20, 1000, 20000, 2000, 'Sippp');
INSERT INTO `uangsuplayer` (`idUangSuplayer`, `idDetailOrdersUangSuplayer`, `noTransaksiUangSuplayer`, `idSuplayerUangSuplayer`, `qtyUangSuplayer`, `hargaUangSuplayer`, `totalUangSuplayer`, `potonganUangSuplayer`, `keteranganUangSuplayer`) VALUES (4, 4, '120002', 2, 13, 1000, 13000, 9000, 'oke');


#
# TABLE STRUCTURE FOR: rejectbahankeluar
#

DROP TABLE IF EXISTS `rejectbahankeluar`;

CREATE TABLE `rejectbahankeluar` (
  `idRejectKeluar` int(11) NOT NULL AUTO_INCREMENT,
  `idBahanKeluarReject` int(5) NOT NULL,
  `qtyReject` int(5) NOT NULL,
  `hargaReject` int(11) NOT NULL,
  PRIMARY KEY (`idRejectKeluar`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

#
# TABLE STRUCTURE FOR: tempbahanmasuk
#

DROP TABLE IF EXISTS `tempbahanmasuk`;

CREATE TABLE `tempbahanmasuk` (
  `idTempBahanMasuk` int(11) NOT NULL AUTO_INCREMENT,
  `idBahanMasukTemp` int(11) NOT NULL,
  `qtyBahanMasukTemp` int(5) NOT NULL,
  `hargaBahanMasukTemp` int(11) NOT NULL,
  PRIMARY KEY (`idTempBahanMasuk`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

#
# TABLE STRUCTURE FOR: detailbahanmasuk
#

DROP TABLE IF EXISTS `detailbahanmasuk`;

CREATE TABLE `detailbahanmasuk` (
  `idDetailBahanMasuk` int(11) NOT NULL AUTO_INCREMENT,
  `idBahanMasukDetail` int(11) NOT NULL,
  `noTransaksiDetailBahanMasuk` varchar(100) NOT NULL,
  `qtyDetailBahanMasuk` int(5) NOT NULL,
  `hargaDetailBahanMasuk` int(11) NOT NULL,
  PRIMARY KEY (`idDetailBahanMasuk`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

#
# TABLE STRUCTURE FOR: transaksibahanmasuk
#

DROP TABLE IF EXISTS `transaksibahanmasuk`;

CREATE TABLE `transaksibahanmasuk` (
  `idTransaksiBahanMasuk` int(11) NOT NULL AUTO_INCREMENT,
  `namaPelangganTransaksiBahanMasuk` varchar(200) NOT NULL,
  `noTransaksiBahanMasuk` varchar(100) NOT NULL,
  `totalTransaksiBahanMasuk` int(11) NOT NULL,
  `bayarTransaksiBahanMasuk` int(11) NOT NULL,
  `kembalianTransaksiBahanMasuk` float NOT NULL,
  `tanggalTransaksiBahanMasuk` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`idTransaksiBahanMasuk`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

#
# TABLE STRUCTURE FOR: notapembelian
#

DROP TABLE IF EXISTS `notapembelian`;

CREATE TABLE `notapembelian` (
  `idNotaPembelian` int(11) NOT NULL AUTO_INCREMENT,
  `keteranganNotaPembelian` text NOT NULL,
  `gambarNotaPembelian` varchar(200) NOT NULL,
  `tanggalNotaPembelian` date NOT NULL,
  PRIMARY KEY (`idNotaPembelian`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4;

INSERT INTO `notapembelian` (`idNotaPembelian`, `keteranganNotaPembelian`, `gambarNotaPembelian`, `tanggalNotaPembelian`) VALUES (1, 'cek', '157bfca11ddd948d94fe022b3f1f4730.png', '2020-07-22');
INSERT INTO `notapembelian` (`idNotaPembelian`, `keteranganNotaPembelian`, `gambarNotaPembelian`, `tanggalNotaPembelian`) VALUES (2, 'wfesefd', '4aac32c5ebbbaf350a3e319dcd951f1a.jpg', '2020-07-23');
INSERT INTO `notapembelian` (`idNotaPembelian`, `keteranganNotaPembelian`, `gambarNotaPembelian`, `tanggalNotaPembelian`) VALUES (3, 'ewrw', '287f9b66b0bbbaef911b32e15c829e87.jpg', '2020-07-22');
INSERT INTO `notapembelian` (`idNotaPembelian`, `keteranganNotaPembelian`, `gambarNotaPembelian`, `tanggalNotaPembelian`) VALUES (4, 'ewrw', '49a3083a5b5bc10523ba7cd488b21708.jpg', '2020-07-22');


